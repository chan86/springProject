package com.test.project4;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {

	//의존 객체
	@Autowired
	private SqlSessionTemplate template;

	public List<BoardDTO> list(String cityname) {
		
		//select
		//1. selectOne : 결과셋 레코드 1줄
		//2. selectList : 결과셋 레코드 여러줄 
		System.out.println("DAO" + cityname);
		
		return template.selectList("board.list", cityname);
	}

	public BoardDTO getView(String seq) {
		// TODO Auto-generated method stub
		return template.selectOne("board.getView", seq);
	}

	/*
	public BoardDTO get(String seq) {
		
		return template.selectOne("board.get", seq);
	}
	*/
	

}
