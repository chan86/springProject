package com.test.project4;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.test.project4.BoardDTO;

@Controller
public class BoardController {

	//의존 객체(service)
	@Autowired
	private IBoardService service;
	
	//템플릿
	@RequestMapping(value = "/template.action", method = { RequestMethod.GET })
	public String template(HttpServletRequest req, HttpServletResponse resp, HttpSession session) {

		return "template";
		
	}//template

	
	
	
	
	
	
	@RequestMapping(value = "/mainpage.action", method = { RequestMethod.GET })
	public String mainpage(HttpServletRequest req, HttpServletResponse resp, HttpSession session) {
		
		return "mainpage";
		
	}//mainpage
	
	
	@RequestMapping(value = "/main_lyc.action", method = { RequestMethod.GET })
	public String main_lyc(HttpServletRequest req, HttpServletResponse resp, HttpSession session) {
		
		return "main_lyc";
		
	}//main_lyc

	
	@RequestMapping(value = "/seeList_lyc.action", method = { RequestMethod.GET })
	public String seeList_lyc(HttpServletRequest req, HttpServletResponse resp, HttpSession session) {
		
		return "seeList_lyc";
		
	}//seeList_lyc

	
	/**
	 * see_lyc 에서 보낸 ajax 요청 처리하는 메소드
	 * @param req
	 * @param resp
	 * @param session
	 * @param cityname
	 * @throws ServletException
	 * @throws IOException
	 */
	@RequestMapping(value = "/seeListOK_lyc.action", method = { RequestMethod.GET })
	public void seeListOK_lyc(HttpServletRequest req, HttpServletResponse resp, HttpSession session, String cityname) throws ServletException, IOException {
		
		
		//System.out.println(name);
		
		//1. 서비스 위임 > DB 작업 > select
		//2. 결과 반환 + 타일즈 호출
		System.out.println("Controller" + cityname);
		List<BoardDTO> list = service.list(cityname);
		
		
		//json 형식으로 PrintWrite 해주기
		resp.setContentType("application/json"); //MIME type
		resp.setCharacterEncoding("UTF-8");
		
		PrintWriter writer = resp.getWriter();
		
		
		writer.print("[");
		for(int i=0; i<list.size(); i++) {
		  
			writer.print("{"); //writer.printf("\"seq\":\"%s\",", mlist.get(i).getSeq());
			writer.printf("\"seq\":\"%s\",", list.get(i).getSeq());
			writer.printf("\"name\":\"%s\",", list.get(i).getName());
			writer.printf("\"image\":\"%s\",", list.get(i).getImage());
			writer.printf("\"cityname\":\"%s\"", list.get(i).getCityname());
			  
			if(i == list.size()-1) { 
				writer.print("}"); 
			} else {
				writer.print("},\r\n"); 
			} 
		}
		writer.print("]");
		 
		
		//writer.print("[");
//		writer.print("{");
//			writer.printf("\"name\":\"%s\"", name);
//		writer.print("}");
		//writer.print("]");
		//System.out.println(mlist.get(mlist.size()-1).getSeq());
		
		writer.close();
		
	}//seeListOK_lyc

	
	
	
	@RequestMapping(value = "/seeView_lyc.action", method = { RequestMethod.GET })
	public String seeView_lyc(HttpServletRequest req, HttpServletResponse resp, HttpSession session, String seq) {
		
		BoardDTO view = service.getView(seq);
		
		//System.out.println(view[0].);
		req.setAttribute("view", view);
		
		return "seeView_lyc";
		
	}//seeView_lyc
	
	
	
	@RequestMapping(value = "/add.action", method = { RequestMethod.GET })
	public String add(HttpServletRequest req, HttpServletResponse resp, HttpSession session) {

		
		
		return "add";
		
	}//add
	
	
}
