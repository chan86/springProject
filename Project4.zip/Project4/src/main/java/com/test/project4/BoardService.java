package com.test.project4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service //@Autowired와 한쌍
public class BoardService implements IBoardService {

	//의존 객체
	@Autowired
	private BoardDAO dao;

	@Override
	public List<BoardDTO> list(String cityname) {
		
		System.out.println("Service" + cityname);
		List<BoardDTO> list = dao.list(cityname);
		
		return list;
		
	}

	@Override
	public BoardDTO getView(String seq) {
		
		BoardDTO view = dao.getView(seq);
		
		
		return view;
	}
	
	/*
	@Override
	public BoardDTO get(String seq, GetMode mode) {
		
		BoardDTO dto = dao.get(seq);
		
		if(mode == GetMode.VIEW) {
			//중간 - 여러가지 조작 + 추가 업무 : 역할
			//1. 태그 미적용
			//2. 개행처리
			dto.setContent(dto.getContent().replace("<", "&lt;").replace(">", "&gt;"));
			dto.setSubject(dto.getSubject().replace("<", "&lt;").replace(">", "&gt;"));
			dto.setName(dto.getName().replace("<", "&lt;").replace(">", "&gt;"));
			
			dto.setContent(dto.getContent().replace("\r\n", "<br>"));
			
			dto.setContent(dto.getContent().replace("#약속", "<span class='glyphicon glyphicon-calendar'></span>"));
		}
		
		return dto;
	}
	 */
	
	
	
}
