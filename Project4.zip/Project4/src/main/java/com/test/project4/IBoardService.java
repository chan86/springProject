package com.test.project4;

import java.util.List;

public interface IBoardService {

	List<BoardDTO> list(String cityname);

	BoardDTO getView(String seq);

}
