package com.test.project4;

public enum GetMode {

	VIEW,
	EDIT
}
