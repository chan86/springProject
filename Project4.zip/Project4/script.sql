CREATE TABLE TBLSEE(
    seq NUMBER PRIMARY KEY,
    name varchar2(50) not null,
    image varchar2(30) default('none.jpg') null,
    cityname varchar2(30) not null
);

CREATE SEQUENCE see_seq;

INSERT INTO TBLSEE (seq, name, image, cityname) 
    VALUES (see_seq.nextval, '태안 바다', 'sea.jpg', '태안');
    
commit;

select 
		*
		from tblSee
			where cityname = '태안';